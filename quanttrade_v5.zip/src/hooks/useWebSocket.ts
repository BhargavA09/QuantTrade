import { useEffect, useRef, useState, useCallback } from 'react';

export interface PriceUpdate {
  type: 'PRICE_UPDATE';
  ticker: string;
  price: number;
  change: number;
  changePercent: number;
  volume?: number;
  high?: number;
  low?: number;
  open?: number;
  previousClose?: number;
  marketCap?: number;
  peRatio?: number;
  dividendYield?: number;
  timestamp: string;
}

export type ConnectionState = 'connecting' | 'connected' | 'reconnecting' | 'disconnected';

export function useWebSocket(tickers: string[]) {
  const [lastUpdate, setLastUpdate] = useState<PriceUpdate | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const maxReconnectAttempts = 10;

  const [isConnected, setIsConnected] = useState(false);
  const [connectionState, setConnectionState] = useState<ConnectionState>('connecting');

  const connect = useCallback(() => {
    if (socketRef.current?.readyState === WebSocket.OPEN) return;

    setConnectionState(reconnectAttemptsRef.current > 0 ? 'reconnecting' : 'connecting');

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = import.meta.env.VITE_WS_URL || `${protocol}//${host}`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log('WebSocket connected');
      setIsConnected(true);
      setConnectionState('connected');
      reconnectAttemptsRef.current = 0; // Reset attempts on successful connection
      
      // Subscribe to all current tickers
      tickers.forEach(ticker => {
        socket.send(JSON.stringify({ type: 'SUBSCRIBE', ticker }));
      });
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'PRICE_UPDATE') {
          setLastUpdate(data);
        }
      } catch (e) {
        console.error('WebSocket message error:', e);
      }
    };

    socket.onclose = () => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      
      if (reconnectAttemptsRef.current < maxReconnectAttempts) {
        setConnectionState('reconnecting');
        // Exponential backoff: 1s, 2s, 4s, 8s, etc., capped at 30s
        const backoffTime = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 30000);
        console.log(`Reconnecting in ${backoffTime}ms (Attempt ${reconnectAttemptsRef.current + 1})`);
        
        reconnectTimeoutRef.current = setTimeout(() => {
          reconnectAttemptsRef.current += 1;
          connect();
        }, backoffTime);
      } else {
        setConnectionState('disconnected');
        console.error('Max WebSocket reconnection attempts reached.');
      }
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      socket.close();
    };

    socketRef.current = socket;
  }, [tickers]);

  useEffect(() => {
    connect();
    return () => {
      if (socketRef.current) {
        // Prevent reconnect loop on unmount
        socketRef.current.onclose = null; 
        socketRef.current.close();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, []); // Only connect once on mount

  // Subscribe to new tickers when they are added
  useEffect(() => {
    if (isConnected && socketRef.current?.readyState === WebSocket.OPEN) {
      tickers.forEach(ticker => {
        socketRef.current?.send(JSON.stringify({ type: 'SUBSCRIBE', ticker }));
      });
    }
  }, [tickers, isConnected]);

  const subscribe = (ticker: string) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: 'SUBSCRIBE', ticker }));
    }
  };

  const unsubscribe = (ticker: string) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: 'UNSUBSCRIBE', ticker }));
    }
  };

  return { lastUpdate, isConnected, connectionState, subscribe, unsubscribe };
}
