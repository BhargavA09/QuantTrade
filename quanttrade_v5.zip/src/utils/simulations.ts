/**
 * Monte Carlo Simulation Utility
 * Optimized for performance using typed arrays if possible
 */

export interface SimulationResult {
  simulations: number[][];
  forecast: { date: string; price: number }[];
  simBounds: { pUpper: number; pLower: number; min: number; max: number; median: number }[];
}

export const runMonteCarlo = (
  currentPrice: number,
  mean: number,
  stdDev: number,
  numSims: number = 100,
  confInterval: number = 0.8,
  days: number = 10
): SimulationResult => {
  const simulations: number[][] = [];
  const dailyReturns: number[][] = [];

  // Generate simulations
  for (let i = 0; i < 5; i++) { // We only return 5 paths for UI performance
    const path = [currentPrice];
    let lastPrice = currentPrice;
    for (let d = 0; d < days; d++) {
      const drift = mean - 0.5 * Math.pow(stdDev, 2);
      const shock = stdDev * boxMullerTransform();
      const nextPrice = lastPrice * Math.exp(drift + shock);
      path.push(nextPrice);
      lastPrice = nextPrice;
    }
    simulations.push(path);
  }

  // Calculate confidence intervals (using a larger sample size for accuracy)
  const forecast: { date: string; price: number }[] = [];
  const simBounds: { pUpper: number; pLower: number; min: number; max: number; median: number }[] = [];

  // Base forecast (mean path)
  let lastForecastPrice = currentPrice;
  const today = new Date();

  for (let d = 1; d <= days; d++) {
    const forecastDate = new Date(today);
    forecastDate.setDate(today.getDate() + d);
    const dateStr = forecastDate.toISOString().split('T')[0];
    
    const drift = mean - 0.5 * Math.pow(stdDev, 2);
    const nextForecastPrice = lastForecastPrice * Math.exp(drift);
    forecast.push({ date: dateStr, price: nextForecastPrice });
    lastForecastPrice = nextForecastPrice;

    // Calculate bounds for this day
    const dayPrices: number[] = [];
    for (let s = 0; s < numSims; s++) {
      let p = currentPrice;
      for (let step = 0; step < d; step++) {
        p *= Math.exp(drift + stdDev * boxMullerTransform());
      }
      dayPrices.push(p);
    }
    dayPrices.sort((a, b) => a - b);
    const lowerIdx = Math.floor(numSims * (1 - confInterval) / 2);
    const upperIdx = Math.floor(numSims * (1 - (1 - confInterval) / 2));
    const medianIdx = Math.floor(numSims / 2);
    
    simBounds.push({
      pLower: dayPrices[lowerIdx] || dayPrices[0],
      pUpper: dayPrices[upperIdx] || dayPrices[dayPrices.length - 1],
      min: dayPrices[0],
      max: dayPrices[dayPrices.length - 1],
      median: dayPrices[medianIdx]
    });
  }

  return { simulations, forecast, simBounds };
};

function boxMullerTransform() {
  const u1 = Math.random();
  const u2 = Math.random();
  return Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
}
