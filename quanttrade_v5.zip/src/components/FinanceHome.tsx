import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  TrendingUp, 
  TrendingDown, 
  ChevronRight, 
  Star, 
  Plus,
  X,
  Loader2,
  Globe,
  Zap,
  BarChart3,
  Activity
} from 'lucide-react';
import { fetchMarketOverview, searchTicker } from '../services/api';
import { cn } from '../utils/cn';

interface FinanceHomeProps {
  onSelectTicker: (ticker: string) => void;
  onAddWatchlist?: (ticker: string) => void;
  watchlist?: string[];
}

export const FinanceHome: React.FC<FinanceHomeProps> = ({ 
  onSelectTicker, 
  onAddWatchlist,
  watchlist = []
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [marketData, setMarketData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeMarketTab, setActiveMarketTab] = useState<'us' | 'crypto' | 'commodities'>('us');

  useEffect(() => {
    const loadMarketData = async () => {
      try {
        const data = await fetchMarketOverview();
        setMarketData(data);
      } catch (error) {
        console.error("Failed to load market data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadMarketData();
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      const ticker = await searchTicker(searchQuery);
      if (ticker) {
        onSelectTicker(ticker);
        setSearchQuery('');
      }
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsSearching(false);
    }
  };

  const marketIndices = marketData?.[activeMarketTab] || [];

  return (
    <div className="flex flex-col gap-6 p-6 max-w-7xl mx-auto w-full">
      {/* Search Header */}
      <div className="relative group">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 group-focus-within:text-emerald-500 transition-colors" size={20} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for stocks, ETFs, or crypto (e.g. AAPL, BTC-USD)..."
            className="w-full bg-zinc-900/50 border border-zinc-800 rounded-2xl py-4 pl-12 pr-4 text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500/50 transition-all text-lg"
          />
          {isSearching && (
            <div className="absolute right-4 top-1/2 -translate-y-1/2">
              <Loader2 className="animate-spin text-emerald-500" size={20} />
            </div>
          )}
        </form>
      </div>

      {/* Market Overview Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-zinc-100 flex items-center gap-2">
              <Globe size={20} className="text-emerald-500" />
              Market Overview
            </h2>
            <div className="flex bg-zinc-900/50 p-1 rounded-xl border border-zinc-800">
              {(['us', 'crypto', 'commodities'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveMarketTab(tab)}
                  className={cn(
                    "px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all",
                    activeMarketTab === tab 
                      ? "bg-emerald-500 text-zinc-950 shadow-lg shadow-emerald-500/20" 
                      : "text-zinc-500 hover:text-zinc-300"
                  )}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {isLoading ? (
              Array(4).fill(0).map((_, i) => (
                <div key={i} className="h-24 bg-zinc-900/50 rounded-2xl animate-pulse border border-zinc-800" />
              ))
            ) : (
              marketIndices.slice(0, 4).map((item: any) => (
                <motion.div
                  key={item.ticker}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  onClick={() => onSelectTicker(item.ticker)}
                  className="bg-zinc-900/40 hover:bg-zinc-900/60 border border-zinc-800/50 p-4 rounded-2xl cursor-pointer transition-all group relative overflow-hidden"
                >
                  <div className="absolute right-0 top-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <ChevronRight size={16} className="text-zinc-600" />
                  </div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-sm font-black text-zinc-100 uppercase tracking-tight">{item.ticker.replace('^', '')}</h3>
                      <p className="text-[10px] text-zinc-500 font-medium truncate max-w-[120px]">{item.name}</p>
                    </div>
                    <div className={cn(
                      "px-2 py-1 rounded-lg text-[10px] font-black",
                      item.changePercent >= 0 ? "bg-emerald-500/10 text-emerald-400" : "bg-rose-500/10 text-rose-400"
                    )}>
                      {item.changePercent >= 0 ? '+' : ''}{item.changePercent.toFixed(2)}%
                    </div>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-mono font-bold text-zinc-100">
                      {item.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>

        {/* Trending / Most Active */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-zinc-100 flex items-center gap-2">
            <Zap size={20} className="text-amber-500" />
            Trending Now
          </h2>
          <div className="bg-zinc-900/40 border border-zinc-800/50 rounded-2xl overflow-hidden">
            {isLoading ? (
              <div className="p-8 flex justify-center">
                <Loader2 className="animate-spin text-zinc-700" />
              </div>
            ) : (
              <div className="divide-y divide-zinc-800/50">
                {(marketData?.us || []).slice(4, 10).map((item: any) => (
                  <button
                    key={item.ticker}
                    onClick={() => onSelectTicker(item.ticker)}
                    className="w-full flex items-center justify-between p-4 hover:bg-zinc-800/30 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-zinc-800 flex items-center justify-center text-[10px] font-bold text-zinc-400 group-hover:bg-emerald-500 group-hover:text-zinc-950 transition-colors">
                        {item.ticker.substring(0, 2)}
                      </div>
                      <div className="text-left">
                        <div className="text-sm font-bold text-zinc-100">{item.ticker}</div>
                        <div className="text-[10px] text-zinc-500">{item.name}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-mono font-bold text-zinc-100">
                        {item.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </div>
                      <div className={cn(
                        "text-[10px] font-bold",
                        item.changePercent >= 0 ? "text-emerald-400" : "text-rose-400"
                      )}>
                        {item.changePercent >= 0 ? '+' : ''}{item.changePercent.toFixed(2)}%
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Watchlist Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-zinc-100 flex items-center gap-2">
            <Star size={20} className="text-emerald-500" />
            Your Watchlist
          </h2>
          <button className="text-xs font-bold text-emerald-500 hover:text-emerald-400 flex items-center gap-1">
            <Plus size={14} />
            Edit Watchlist
          </button>
        </div>
        
        {watchlist.length === 0 ? (
          <div className="bg-zinc-900/30 border border-dashed border-zinc-800 rounded-3xl p-12 text-center">
            <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center mx-auto mb-4 border border-zinc-800">
              <Star size={24} className="text-zinc-700" />
            </div>
            <h3 className="text-zinc-300 font-bold mb-2">Your watchlist is empty</h3>
            <p className="text-zinc-500 text-sm max-w-xs mx-auto mb-6">
              Add stocks to your watchlist to track their performance in real-time.
            </p>
            <button className="bg-zinc-100 text-zinc-950 px-6 py-2 rounded-xl font-bold text-sm hover:bg-white transition-colors">
              Add Symbols
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
             {/* Watchlist items would go here */}
          </div>
        )}
      </div>

      {/* Market Stats / News */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-3xl p-6 relative overflow-hidden group">
          <div className="absolute -right-8 -bottom-8 opacity-10 group-hover:scale-110 transition-transform duration-700">
            <BarChart3 size={160} className="text-emerald-500" />
          </div>
          <div className="relative z-10">
            <div className="bg-emerald-500/20 w-10 h-10 rounded-xl flex items-center justify-center mb-4">
              <Activity className="text-emerald-400" size={20} />
            </div>
            <h3 className="text-lg font-bold text-zinc-100 mb-2">Market Intelligence</h3>
            <p className="text-zinc-400 text-sm mb-4 leading-relaxed">
              Our AI models are currently analyzing global trade flows and sentiment shifts. 
              Volatility is currently <span className="text-emerald-400 font-bold">low</span> across major indices.
            </p>
            <button className="text-xs font-black uppercase tracking-widest text-emerald-400 hover:text-emerald-300 transition-colors">
              View Full Report →
            </button>
          </div>
        </div>

        <div className="bg-zinc-900/40 border border-zinc-800/50 rounded-3xl p-6">
          <h3 className="text-lg font-bold text-zinc-100 mb-4">Market News</h3>
          <div className="space-y-4">
            {[
              { title: "Fed signals potential rate pause in upcoming meeting", time: "2h ago", source: "MarketWatch" },
              { title: "Tech stocks rally as AI demand continues to surge", time: "4h ago", source: "Bloomberg" },
              { title: "Oil prices stabilize amid global supply concerns", time: "5h ago", source: "Reuters" }
            ].map((news, i) => (
              <div key={i} className="group cursor-pointer">
                <div className="flex justify-between items-start mb-1">
                  <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">{news.source}</span>
                  <span className="text-[10px] text-zinc-600">{news.time}</span>
                </div>
                <h4 className="text-sm font-bold text-zinc-300 group-hover:text-zinc-100 transition-colors line-clamp-1">
                  {news.title}
                </h4>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
