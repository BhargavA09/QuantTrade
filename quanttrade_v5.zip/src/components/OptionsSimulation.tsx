import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Activity, TrendingUp, TrendingDown, ChevronRight, Info, Layers, BarChart3, Loader2 } from 'lucide-react';
import { StockData } from '../types';
import { fetchOptions } from '../services/api';

interface OptionsSimulationProps {
  data: StockData;
}

const OptionsSimulation: React.FC<OptionsSimulationProps> = ({ data }) => {
  const currentPrice = data.currentPrice;
  const [expiration, setExpiration] = useState('');
  const [optionType, setOptionType] = useState<'calls' | 'puts'>('calls');
  const [optionsData, setOptionsData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadOptions = async () => {
      setLoading(true);
      const result = await fetchOptions(data.ticker, expiration || undefined);
      if (result) {
        setOptionsData(result);
        if (!expiration && result.expirationDates && result.expirationDates.length > 0) {
          setExpiration(result.expirationDates[0].split('T')[0]);
        }
      }
      setLoading(false);
    };
    loadOptions();
  }, [data.ticker, expiration]);

  const chain = optionsData?.options?.[0]?.[optionType] || [];
  const expirations = optionsData?.expirationDates || [];

  // Filter chain to show strikes around current price
  const filteredChain = chain.filter((opt: any) => {
    const distance = Math.abs(opt.strike - currentPrice) / currentPrice;
    return distance < 0.2; // Show strikes within 20% of current price
  }).sort((a: any, b: any) => a.strike - b.strike);

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="glass-card p-6 bg-gradient-to-br from-zinc-900 to-zinc-950 border-zinc-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20">
              <Layers size={20} className="text-purple-400" />
            </div>
            <div>
              <h2 className="text-lg font-black text-zinc-100 tracking-tight">Options Chain Analysis</h2>
              <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest">{data.ticker} Real-Time Derivatives</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex bg-zinc-900 p-1 rounded-xl border border-zinc-800">
              <button 
                onClick={() => setOptionType('calls')}
                className={`px-6 py-2 text-[10px] font-black rounded-lg uppercase transition-all ${optionType === 'calls' ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                Calls
              </button>
              <button 
                onClick={() => setOptionType('puts')}
                className={`px-6 py-2 text-[10px] font-black rounded-lg uppercase transition-all ${optionType === 'puts' ? 'bg-rose-500 text-black shadow-lg shadow-rose-500/20' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                Puts
              </button>
            </div>
            
            <select 
              value={expiration}
              onChange={(e) => setExpiration(e.target.value)}
              className="bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs font-bold rounded-xl px-4 py-2 focus:outline-none focus:border-purple-500/50"
            >
              {expirations.map((exp: string) => {
                const date = new Date(exp);
                return (
                  <option key={exp} value={exp.split('T')[0]}>
                    {date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </option>
                );
              })}
            </select>
          </div>
        </div>
      </div>

      {/* Options Chain Table */}
      <div className="glass-card overflow-hidden relative min-h-[300px]">
        {loading && (
          <div className="absolute inset-0 z-10 bg-zinc-950/50 backdrop-blur-sm flex items-center justify-center">
            <Loader2 className="animate-spin text-purple-400" size={32} />
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-900/50 border-b border-zinc-800">
                <th className="p-4 text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Strike</th>
                <th className="p-4 text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-right">Last Price</th>
                <th className="p-4 text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-right">Bid / Ask</th>
                <th className="p-4 text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-right">Vol / OI</th>
                <th className="p-4 text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-right">Implied Vol</th>
                <th className="p-4 text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredChain.map((opt: any, i: number) => (
                <tr 
                  key={i} 
                  className={`border-b border-zinc-800/50 hover:bg-zinc-900/30 transition-colors ${opt.inTheMoney ? 'bg-zinc-900/10' : ''}`}
                >
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-black font-mono ${Math.abs(opt.strike - currentPrice) < (currentPrice * 0.01) ? 'text-purple-400' : 'text-zinc-200'}`}>
                        ${opt.strike.toFixed(2)}
                      </span>
                      {opt.inTheMoney && (
                        <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-zinc-800 text-zinc-400 uppercase tracking-widest">ITM</span>
                      )}
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <span className="text-sm font-bold font-mono text-zinc-100">${opt.lastPrice?.toFixed(2) || '0.00'}</span>
                    <div className={`text-[10px] font-bold ${opt.change > 0 ? 'text-emerald-400' : opt.change < 0 ? 'text-rose-400' : 'text-zinc-500'}`}>
                      {opt.change > 0 ? '+' : ''}{opt.change?.toFixed(2) || '0.00'}
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <div className="flex flex-col items-end font-mono">
                      <span className="text-xs text-zinc-300">${opt.bid?.toFixed(2) || '0.00'}</span>
                      <span className="text-[10px] text-zinc-500">${opt.ask?.toFixed(2) || '0.00'}</span>
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <div className="flex flex-col items-end">
                      <span className="text-xs font-bold text-zinc-300">{opt.volume?.toLocaleString() || 0}</span>
                      <span className="text-[10px] text-zinc-600">{opt.openInterest?.toLocaleString() || 0}</span>
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <span className="text-xs font-mono text-zinc-400">{((opt.impliedVolatility || 0) * 100).toFixed(1)}%</span>
                  </td>
                  <td className="p-4 text-center">
                    <button className="px-3 py-1.5 rounded-lg bg-purple-500/10 border border-purple-500/20 text-[10px] font-bold text-purple-400 uppercase tracking-widest hover:bg-purple-500/20 transition-colors">
                      Trade
                    </button>
                  </td>
                </tr>
              ))}
              {filteredChain.length === 0 && !loading && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-zinc-500 text-sm">
                    No options data available for this expiration.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Greeks Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Underlying', value: `$${currentPrice.toFixed(2)}`, desc: 'Current Price' },
          { label: 'Total Volume', value: filteredChain.reduce((sum: number, opt: any) => sum + (opt.volume || 0), 0).toLocaleString(), desc: 'Selected Expiration' },
          { label: 'Total OI', value: filteredChain.reduce((sum: number, opt: any) => sum + (opt.openInterest || 0), 0).toLocaleString(), desc: 'Selected Expiration' },
          { label: 'Avg IV', value: `${(filteredChain.reduce((sum: number, opt: any) => sum + (opt.impliedVolatility || 0), 0) / (filteredChain.length || 1) * 100).toFixed(1)}%`, desc: 'Selected Expiration' }
        ].map((stat, i) => (
          <div key={i} className="glass-card p-4 border-zinc-800/50">
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1">{stat.label}</p>
            <p className="text-xl font-black font-mono text-zinc-100">{stat.value}</p>
            <p className="text-[10px] text-zinc-600 mt-1">{stat.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OptionsSimulation;
